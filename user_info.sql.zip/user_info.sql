-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 19, 2021 at 06:25 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `technosoft`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE IF NOT EXISTS `user_info` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(60) NOT NULL,
  `lname` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `designation` varchar(60) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `hobbies` varchar(100) NOT NULL,
  `reg_date` varchar(30) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `fname`, `lname`, `email`, `dob`, `mobile`, `designation`, `gender`, `hobbies`, `reg_date`) VALUES
(1, 'Sandhya ', 'Maurya', 'sadhyagkgqp@gmail.com', '2000-07-05', '8887414621', 'web developer', 'female', 'singing,cooking,stiching', '2021-08-19'),
(3, 'Navnish', 'Kumar', 'navnish@gmail.com', '1999-02-09', '7687564533', 'Android developer', 'male', 'dancing,cooking', '2021-08-19');
